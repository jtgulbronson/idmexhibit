window.onload = function () {
    // $('#inner').css('top', '-820px');
    $("#inner").animate({
        top: '0',
        duration: "slow"
    });
    // Setting up colors array
    var colors = [];
    var name = [];
    var location = [];
    var description = [];
    var spices = [];
    var spiceName = [];
    var count = 0;
    var energy = {};
    var form = {};
    var detailEnergy = {};
    var highlightCount = 0;
    var userComment;
    var socket = io.connect();


    socket.on('connect', function () {

    })

    socket.on('loadAll', function (energies) {});

    //----- adding the name
    var toName = $(".next-1");
    toName.hammer().on("tap", function () {

        if ($('#username').val() == '' && $('#userloc').val() == '') {
            $('.error-mess').css('color', '#a64a60');

        } else if ($('#username').val() == '' && $('#userloc').val()) {
            $('#username-error').css('color', '#a64a60');
            $('#userloc-error').css('color', 'transparent');

        } else if ($('#username').val() && $('#userloc').val() == '') {
            $('#username-error').css('color', 'transparent');
            $('#userloc-error').css('color', '#a64a60');

        } else {
            $("#inner").animate({
                left: '-2224',
                duration: "slow"
            });
            name = $('#username').val();
            location = $('#userloc').val();

            console.log(name);
            console.log(location);

            return name;
            return location;

        }


    });

    //----- Selecting all the descriptions
    var toDescribe = $(".describe");
    toDescribe.hammer().on("tap", function () {
        $(this).css('background', '#9aaf87');

        $('#desc').css('background', `url('img/selections/${this.attributes["data-desc"].value}.svg') no-repeat center`);

        // let currentDesc = $.attributes["name"].value;
        description.push(this.attributes["data-desc"].value);
        console.log(description);
        //Pushing name value to colors array
        // description.push(currentDesc);
        return description;
    });

    var toSpice = $('.spice');
    toSpice.hammer().on("tap", function () {
        console.log('this is a thing');
        $(this).css('background', `url('img/fourth/spice/${this.attributes["data-spice"].value}.svg') no-repeat center`);
        $(this).css('color', '#f0eceb');
        console.log('tap spice successful');

        //Making currentHex the name value of colors
        let currentHex = this.attributes["name"].value;
        spices.push(this.attributes["data-spice"].value);
        //Pushing name value to colors array
        colors.push(currentHex);
        console.log(colors);


        return colors
        return spices;
    });

    var toCraft = $(".q3 .next");
    toCraft.hammer().on("tap", function () {
        $("#inner").animate({
            left: '-4448',
            duration: "slow"
        });
        console.log('crafted');
        if (spices.length > 1) {
            $('#spiceOne').css('background', `url('img/fourth/spice/${spices[0]}.svg') no-repeat center`);
            console.log(spices);
            $('#desc span').html(description[0]);
            $('#spiceOne span').html(spices[0]);
            $('#spiceTwo').css('background', `url('img/fourth/spice/${spices[1]}.svg') no-repeat center`);
            $('#spiceTwo span').html(spices[1]);
            $('#spiceThree').css('background', `url('img/fourth/spice/${spices[2]}.svg') no-repeat center`);
            $('#spiceThree span').html(spices[2]);
        } else if (spices.length == 1) {
            $('#spiceThree').css('background', `url('img/fourth/spice/${spices[0]}.svg') no-repeat center`);
            $('#spiceThree span').html(spices[0]);
        }
    });

    //----- Mixing all the colors
    var toSend = $(".q4 .next");
    toSend.hammer().on("tap", function () {

        console.log('sent over and crafted');
        $("#inner").animate({
            left: '-5559',
            duration: "slow"
        });
        if (spices.length > 1) {
            $('#spiceOne').css('background', `url('img/fourth/spice/${spices[0]}.svg') no-repeat center`);
            console.log(spices);
            $('#desc span').html(description[0]);
            $('#spiceOne span').html(spices[0]);
            $('#spiceTwo').css('background', `url('img/fourth/spice/${spices[1]}.svg') no-repeat center`);
            $('#spiceTwo span').html(spices[1]);
            $('#spiceThree').css('background', `url('img/fourth/spice/${spices[2]}.svg') no-repeat center`);
            $('#spiceThree span').html(spices[2]);
        } else if (spices.length == 1) {
            $('#spiceThree').css('background', `url('img/fourth/spice/${spices[0]}.svg') no-repeat center`);
            $('#spiceThree span').html(spices[0]);
        }

        form = {
            color: colors,
            spices: spices,
            description: description
        }

        socket.emit('createEnergy', form);

    });

    socket.on('completeForm', function (ab) {

        if (ab.description[0] == 'meditator') {

            $('#energy-form').html(`<div class="svg">
            <?xml version="1.0" encoding="UTF-8"?>
            <svg enable-background="new 0 0 1289.6 1128" viewBox="0 0 1289.6 1128" xmlns="http://www.w3.org/2000/svg"
                xmlns:xlink="http://www.w3.org/1999/xlink">
                <g class="en-one">
                <image transform="translate(245 226.63)" width="404" height="776" opacity=".9" overflow="visible" xlink:href="img/energy-left.png"
                />
                <g id="Color">
                <linearGradient id="c${ab.id}" x1="203.22" x2="203.22" y1="977.08" y2="213.25" gradientTransform="translate(0 -192.93)"
                    gradientUnits="userSpaceOnUse">
                    <stop stop-color="${ab.color[0]}" offset="0" />
                    <stop stop-color="${ab.color[2]}" offset="1" />
                </linearGradient>
                <path transform="translate(20)" d="m473.7 981.6s-7.1 9.5-11.3 11.4c-3.3 1.7-9.5 13.6-23.3 8.9-13.5-5.6-55.3-31.8-55.3-31.8l-58.1-29.9s-41.2-23.8-47-32.1-9.7-13.1-17.7-46.6c-8-33.3-27-122.5-27-122.5s-12.5-77.8 9.3-138.5c18.2-50.7 41-123.4 124.4-214.8 73.5-80.7 121-123.5 121-123.5v-5.3s21-21.9 41.3-20.7c14.8-2.6 48.9-4.4 51.8-7s31.5 0.9 33.4 8.6 10.2 50.8 11.1 63.9 3.7 84.6 3.7 84.6v72.2l-3.7 78.2-7.6 85.2s-6.9 65.1-8.2 66.3c-0.7 4.1-16.1 83.4-24.3 95.4-3.1 8.1-20.4 52.7-24.7 59.9-3.2 6.5-36.6 71.2-41 75.5-4.1 6.9-35.5 51.1-46.8 62.6z"
                    fill="url(#c${ab.id})" opacity=".8" />
                    </g>
                    </g>
                    <g class="en-three">
                <image transform="translate(345 523.14)" width="630" height="560" opacity=".9" overflow="visible"
                    xlink:href="img/energy-bottom.png" />
                    <g id="Color3">
                    <linearGradient id="b${ab.id}" x1="-73.767" x2="-73.767" y1="974.01" y2="253.16" gradientTransform="matrix(-.92 .6 .53 .82 70.62 96.58)"
                        gradientUnits="userSpaceOnUse">
                        <stop stop-color="${ab.color[1]}" offset="0" />
                        <stop stop-color="${ab.color[0]}" offset="1" />
                    </linearGradient>
                    <path transform="translate(20)" d="m828.2 1079.5s11 3.3 15.5 2.5c3.7-0.5 15.1 5.2 24.8-6.2 9-12 32.3-55.8 32.3-55.8l35.7-55.9s24-41.6 24.9-51.3 1.8-15.7-8-46.2c-9.7-30.3-37.7-110-37.7-110s-28-67.3-77.3-102c-41.2-29-97.4-72.5-215.7-96.4-104.4-21.1-167.2-27.6-167.2-27.6l-2.6-4.1s-29.3-5.1-46.3 7.2c-14.2 6.3-44.8 24.1-48.6 23.8-3.8-0.4-27 18.4-24.7 25.5s16.5 45.1 22.2 55.7 39.1 67.6 39.1 67.6l36.1 55.8 42.3 58.5 49.3 61.7s38.6 46.5 40.3 46.7c2.7 2.8 55.7 55.6 68.9 60.2 6.8 4.5 44.1 29.3 51.4 32.5 6 3.2 67.4 34.5 73.4 35.4 6.9 3.2 56.3 19.9 71.9 22.4z"
                        fill="url(#b${ab.id})" opacity=".8" />
                </g>
                </g>
                <g class="en-two">
                <image transform="translate(658 288.72)" width="354" height="717" opacity=".9" overflow="visible"
                    xlink:href="img/energy-right.png" />
                    <g id="Color2">
                <linearGradient id="a${ab.id}" x1="218.58" x2="218.58" y1="767.17" y2="68.527" gradientTransform="rotate(160 412.85 433.02)"
                    gradientUnits="userSpaceOnUse">
                    <stop stop-color="${ab.color[2]}" offset="0" />
                    <stop stop-color="${ab.color[1]}" offset="1" />
                </linearGradient>
                <path transform="translate(20)" d="m682 317.9s3.2-10.4 6.2-13.3c2.3-2.5 4-14.6 17.4-14.9 13.4 0.7 57.4 10.5 57.4 10.5l59.3 7.9s42.8 7.8 50.3 13.2 12.4 8.5 29.6 34.9c17.1 26.2 60.8 97.3 60.8 97.3s34.7 63.2 34.5 122.2c-0.2 49.3 2.5 118.9-41.2 223.3-38.5 92-66.3 143.5-66.3 143.5l1.6 4.5s-11.4 25.3-29.2 30.5c-11.9 6.8-40.8 18.8-42.5 21.9s-27.4 8.9-31.4 2.8-24.4-40.7-29.2-51.6-29.1-71.7-29.1-71.7l-22.2-62.2-20.8-68.5-19.6-75.8s-14-58.2-13.3-59.7c-0.7-3.8-11.8-76.8-8.4-89.7 0.2-8 1.4-51.6 2.9-59.2 0.7-6.6 9.7-72.5 12.1-77.6 1.5-7.1 15-54.9 21.1-68.3z"
                    fill="url(#a${ab.id})" opacity=".8" />
                    </g>
                    </g>
                <g class="meditate-circle meditate-one" fill="none" stroke="${ab.color[2]}" stroke-width="10">
                    <circle class="st3 m-circle right" cx="1201.9" cy="913" r="38.5" />
                    <circle class="st3 m-circle left" cx="82.1" cy="913" r="38.5" />
                </g>
                <g class="meditate-circle meditate-two" fill="none" stroke="${ab.color[0]}" stroke-width="10">
                    <circle class="st3 m-circle right" cx="1194.5" cy="718.1" r="38.5" />
                    <circle class="st3 m-circle left" cx="89.5" cy="718.1" r="38.5" />
                </g>
                <g class="meditate-circle meditate-three" fill="none" stroke="${ab.color[2]}" stroke-width="10">
                    <circle class="st3 m-circle right" cx="1156" cy="523.1" r="38.5" />
                    <circle class="st3 m-circle left" cx="128" cy="523.1" r="38.5" />
                </g>
                <g class="meditate-circle meditate-four" fill="none" stroke="${ab.color[1]}" stroke-width="10">
                    <circle class="st3 m-circle right" cx="1085" cy="328.2" r="38.5" />
                    <circle class="st3 m-circle left" cx="199" cy="328.2" r="38.5" />
                </g>
                <g class="meditate-circle meditate-five" fill="none" stroke="${ab.color[0]}" stroke-width="10">
                    <circle class="st3 m-circle right" cx="899.7" cy="147.6" r="38.5" />
                    <circle class="st3 m-circle left" cx="384.4" cy="147.6" r="38.5" />
                </g>
                <g class="meditate-circle meditate-center">
                    <circle class="st3 m-circle" cx="642" cy="70.6" r="38.5" fill="none" stroke="${ab.color[1]}" stroke-width="10"
                    />
                </g>
            </svg>
        </div>`);

        } else if (ab.description[0] == 'dancer') {

            $('#energy-form').html(`<div class="svg">
            <?xml version="1.0" encoding="UTF-8"?><svg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="d${ab.id}"><stop stop-color="${ab.color[0]}" offset="0"/><stop stop-color="${ab.color[1]}" offset=".5"/><stop stop-color="${ab.color[2]}" offset="1"/></linearGradient></defs><g fill="none" stroke="url(#d${ab.id})" stroke-linecap="round"><path class="d-lines d-six" d="m86.9 86.4c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.8-30.2-129.5-11.7-133.2 11.7-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.6 26.5-289.2 6.8c-21-19-6.6-41.5 32.9-55.1z" opacity=".6"/><path class="d-lines d-five" d="m86.9 77.4c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.8-30.2-129.5-11.7-133.2 11.7-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.6 26.5-289.2 6.8c-21-19-6.6-41.5 32.9-55.1z" opacity=".9"/><path class="d-lines d-four" d="m86.9 68.8c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.9-30.2-129.6-11.7-133.3 11.8-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.6 26.5-289.2 6.8c-20.9-19.1-6.5-41.6 33-55.2z" opacity=".6"/><path class="d-lines d-three" d="m86.9 59.4c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.8-30.2-129.5-11.7-133.2 11.7-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.6 26.5-289.2 6.8c-21-19-6.6-41.6 32.9-55.1z" opacity=".9"/><path class="d-lines d-two" d="m86.9 50.4c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.8-30.2-129.5-11.7-133.2 11.7-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.6 26.5-289.2 6.8c-21-19-6.6-41.6 32.9-55.1z" opacity=".6"/><path class="d-lines d-one" d="m86.9 40.6c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.8-30.2-129.5-11.7-133.2 11.7-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.7 26.7-289.3 6.9c-20.9-19.1-6.5-41.6 33-55.2z" opacity=".9"/></g></svg>
        </div>`);

        } else if (ab.description[0] == 'explorer') {

            $('#energy-form').html(`<div class="svg">
            <?xml version="1.0" encoding="UTF-8"?><svg viewBox="0 0 149.32 189.08" xmlns="http://www.w3.org/2000/svg"><g data-name="Layer 2"><g data-name="Layer 8"><g class="explore-el e-five" stroke="${ab.color[0]}"><path class="explore-path" d="M46.51,100.5a1.45,1.45,0,0,0-2.05.91A100.51,100.51,0,0,0,41.69,114c-.08.79-3.28.27-7.76.34a6.58,6.58,0,0,1-6.7-6.73c.15-6.08-.5-10.15-7.35-9.11-9.38,1.43-13.46,2.12-15.9-.16s-4.08,1.18-2,7.1,10.6,2.45,14.27,3.67-2.85,16.52,8.36,16.72,11.26,1.7,15,2.56c2.7.62,7.48-.72,7.4-5-.09-5.07-.06-16.74.33-21.46a1.45,1.45,0,0,0-.8-1.41Z"/><path class="explore-path" d="M102.05,101a1.49,1.49,0,0,1,2.08.91A99.1,99.1,0,0,1,107,114.47c.08.79,3.33.27,7.89.34a6.64,6.64,0,0,0,6.81-6.73c-.15-6.08.51-10.15,7.48-9.11,9.54,1.43,13.68,2.12,16.17-.16s4.15,1.18,2.07,7.1-10.78,2.45-14.51,3.67,2.9,16.52-8.5,16.72-11.45,1.7-15.28,2.56c-2.75.62-7.6-.72-7.52-5,.09-5.07.06-16.74-.33-21.46a1.44,1.44,0,0,1,.81-1.41Z"/></g><g class="explore-el e-six" stroke="${ab.color[1]}"><path class="explore-path" d="M53.92,119.94a1.45,1.45,0,0,0-2.05.91,100.51,100.51,0,0,0-2.78,12.58c-.08.79-3.28.27-7.76.34a6.58,6.58,0,0,1-6.7-6.73c.15-6.08-.5-10.15-7.35-9.11-9.38,1.43-13.46,2.12-15.9-.16s-4.08,1.18-2,7.1,10.6,2.45,14.27,3.67S20.75,145.06,32,145.26s11.26,1.7,15,2.56c2.7.62,7.48-.72,7.4-5-.09-5.07-.06-16.74.33-21.46a1.45,1.45,0,0,0-.8-1.41Z"/><path class="explore-path" d="M94.52,120.43a1.49,1.49,0,0,1,2.08.91,99.1,99.1,0,0,1,2.82,12.58c.08.79,3.33.27,7.89.34a6.64,6.64,0,0,0,6.81-6.73c-.15-6.08.51-10.15,7.48-9.11,9.54,1.43,13.68,2.12,16.17-.16s4.15,1.18,2.07,7.1-10.78,2.45-14.51,3.67,2.9,16.52-8.5,16.72-11.45,1.7-15.28,2.56c-2.75.62-7.6-.72-7.52-5,.09-5.07.06-16.74-.33-21.46a1.44,1.44,0,0,1,.81-1.41Z"/></g><g class="explore-el e-seven" stroke="${ab.color[1]}"><path class="explore-path" d="M62.78,139.34a1.45,1.45,0,0,0-2.05.91,100.51,100.51,0,0,0-2.78,12.58c-.08.79-3.28.27-7.76.34a6.58,6.58,0,0,1-6.7-6.73c.15-6.08-.5-10.15-7.35-9.11-9.38,1.43-13.46,2.12-15.9-.16s-4.08,1.18-2,7.1,10.6,2.45,14.27,3.67-2.85,16.52,8.36,16.72,11.26,1.7,15,2.56c2.7.62,7.48-.72,7.4-5-.09-5.07-.06-16.74.33-21.46a1.45,1.45,0,0,0-.8-1.41Z"/><path class="explore-path" d="M85.52,139.83a1.49,1.49,0,0,1,2.08.91,99.1,99.1,0,0,1,2.82,12.58c.08.79,3.33.27,7.89.34a6.64,6.64,0,0,0,6.81-6.73c-.15-6.08.51-10.15,7.48-9.11,9.54,1.43,13.68,2.12,16.17-.16s4.15,1.18,2.07,7.1-10.78,2.45-14.51,3.67,2.9,16.52-8.5,16.72-11.45,1.7-15.28,2.56c-2.75.62-7.6-.72-7.52-5,.09-5.07.06-16.74-.33-21.46a1.44,1.44,0,0,1,.81-1.41Z"/></g><g class="explore-el e-eight" stroke="${ab.color[1]}"><path class="explore-path" d="M70.67,159.57a1.45,1.45,0,0,0-2.05.91,100.51,100.51,0,0,0-2.78,12.58c-.08.79-3.28.27-7.76.34a6.58,6.58,0,0,1-6.7-6.73c.15-6.08-.5-10.15-7.35-9.11-9.38,1.43-13.46,2.12-15.9-.16s-4.08,1.18-2,7.1,10.6,2.45,14.27,3.67-2.85,16.52,8.36,16.72,11.26,1.7,15,2.56c2.7.62,7.48-.72,7.4-5-.09-5.07-.06-16.74.33-21.46a1.45,1.45,0,0,0-.8-1.41Z"/><path class="explore-path" d="M77.49,160.06a1.49,1.49,0,0,1,2.08.91,99.1,99.1,0,0,1,2.82,12.58c.08.79,3.33.27,7.89.34a6.64,6.64,0,0,0,6.81-6.73c-.15-6.08.51-10.15,7.48-9.11,9.54,1.43,13.68,2.12,16.17-.16s4.15,1.18,2.07,7.1-10.78,2.45-14.51,3.67,2.9,16.52-8.5,16.72-11.45,1.7-15.28,2.56c-2.75.62-7.6-.72-7.52-5,.09-5.07.06-16.74-.33-21.46a1.44,1.44,0,0,1,.81-1.41Z"/></g><g class="explore-el e-four" stroke="${ab.color[0]}"><path class="explore-path" d="M47.27,88.5a1.49,1.49,0,0,1-2.08-.91A99.1,99.1,0,0,1,42.36,75c-.08-.79-3.33-.27-7.89-.34a6.64,6.64,0,0,0-6.81,6.73c.15,6.08-.51,10.15-7.48,9.11C10.64,89.08,6.5,88.39,4,90.67s-4.15-1.18-2.07-7.1,10.78-2.45,14.51-3.67-2.9-16.52,8.5-16.72,11.45-1.7,15.28-2.56c2.75-.62,7.6.72,7.52,5-.09,5.07-.06,16.74.33,21.46a1.44,1.44,0,0,1-.81,1.41Z"/><path class="explore-path" d="M101.5,88.09a1.45,1.45,0,0,0,2.05-.91,100.51,100.51,0,0,0,2.78-12.58c.08-.79,3.28-.27,7.76-.34A6.58,6.58,0,0,1,120.8,81c-.15,6.08.5,10.15,7.35,9.11,9.38-1.43,13.46-2.12,15.9.16s4.08-1.18,2-7.1-10.6-2.45-14.27-3.67,2.85-16.52-8.36-16.72-11.26-1.7-15-2.56c-2.7-.62-7.48.72-7.4,5,.09,5.07.06,16.74-.33,21.46a1.45,1.45,0,0,0,.8,1.41Z"/></g><g class="explore-el e-three" stroke="${ab.color[2]}"><path class="explore-path" d="M54.8,69.05a1.49,1.49,0,0,1-2.08-.91,99.1,99.1,0,0,1-2.82-12.58c-.08-.79-3.33-.27-7.89-.34A6.64,6.64,0,0,0,35.19,62c.15,6.08-.51,10.15-7.48,9.11-9.54-1.43-13.68-2.12-16.17.16S7.4,70,9.47,64.13,20.25,61.68,24,60.46s-2.9-16.52,8.5-16.72S43.93,42,47.76,41.18c2.75-.62,7.6.72,7.52,5-.09,5.07-.06,16.74.33,21.46a1.44,1.44,0,0,1-.81,1.41Z"/><path class="explore-path" d="M94.1,68.64a1.45,1.45,0,0,0,2.05-.91,100.51,100.51,0,0,0,2.78-12.58c.08-.79,3.28-.27,7.76-.34a6.58,6.58,0,0,1,6.7,6.73c-.15,6.08.5,10.15,7.35,9.11,9.38-1.43,13.46-2.12,15.9.16s4.08-1.18,2-7.1-10.6-2.45-14.27-3.67,2.85-16.52-8.36-16.72-11.26-1.7-15-2.56c-2.7-.62-7.48.72-7.4,5,.09,5.07.06,16.74-.33,21.46a1.45,1.45,0,0,0,.8,1.41Z"/></g><g class="explore-el e-two" stroke="${ab.color[2]}"><path class="explore-path" d="M63.8,49.66a1.49,1.49,0,0,1-2.08-.91,99.1,99.1,0,0,1-2.82-12.58c-.08-.79-3.33-.27-7.89-.34a6.64,6.64,0,0,0-6.81,6.73c.15,6.08-.51,10.15-7.48,9.11-9.54-1.43-13.68-2.12-16.17.16s-4.15-1.18-2.07-7.1S29.25,42.28,33,41.06s-2.9-16.52,8.5-16.72,11.45-1.7,15.28-2.56c2.75-.62,7.6.72,7.52,5-.09,5.07-.06,16.74.33,21.46a1.44,1.44,0,0,1-.81,1.41Z"/><path class="explore-path" d="M85.24,49.25a1.45,1.45,0,0,0,2.05-.91,100.51,100.51,0,0,0,2.78-12.58c.08-.79,3.28-.27,7.76-.34a6.58,6.58,0,0,1,6.7,6.73c-.15,6.08.5,10.15,7.35,9.11,9.38-1.43,13.46-2.12,15.9.16s4.08-1.18,2-7.1-10.6-2.45-14.27-3.67,2.85-16.52-8.36-16.72-11.26-1.7-15-2.56c-2.7-.62-7.48.72-7.4,5,.09,5.07.06,16.74-.33,21.46a1.45,1.45,0,0,0,.8,1.41Z"/></g><g class="explore-el e-one" stroke="${ab.color[2]}"><path class="explore-path" d="M71.83,29.42a1.49,1.49,0,0,1-2.08-.91,99.1,99.1,0,0,1-2.82-12.58c-.08-.79-3.33-.27-7.89-.34a6.64,6.64,0,0,0-6.81,6.73c.15,6.08-.51,10.15-7.48,9.11-9.54-1.43-13.68-2.12-16.17.16s-4.15-1.18-2.07-7.1S37.28,22.05,41,20.83s-2.9-16.52,8.5-16.72S61,2.41,64.79,1.55c2.75-.62,7.6.72,7.52,5-.09,5.07-.06,16.74.33,21.46a1.44,1.44,0,0,1-.81,1.41Z"/><path class="explore-path" d="M77.35,29a1.45,1.45,0,0,0,2.05-.91,100.51,100.51,0,0,0,2.78-12.58c.08-.79,3.28-.27,7.76-.34a6.58,6.58,0,0,1,6.7,6.73C96.49,28,97.14,32.06,104,31c9.38-1.43,13.46-2.12,15.9.16s4.08-1.18,2-7.1-10.6-2.45-14.27-3.67S110.52,3.9,99.3,3.7,88,2,84.27,1.14c-2.7-.62-7.48.72-7.4,5,.09,5.07.06,16.74-.33,21.46a1.45,1.45,0,0,0,.8,1.41Z"/></g></g></g></svg>
        </div>`);

        } else {
            return false;
        }

    });

    //----- Textile info to send to the server
    socket.on('toCanvas', function (en) {


        if (en.description[0] == 'meditator') {

            $newMeditate = $(`<div class="m-svg">
            <?xml version="1.0" encoding="UTF-8"?>
            <svg enable-background="new 0 0 1289.6 1128" viewBox="0 0 1289.6 1128" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
            <g class="en-one"><image transform="translate(245 226.63)" width="404" height="776" opacity=".9" overflow="visible" xlink:href="img/energy-left.png"
                />
                <g id="Color">
                <linearGradient id="c${en.id}" x1="203.22" x2="203.22" y1="977.08" y2="213.25" gradientTransform="translate(0 -192.93)"
                    gradientUnits="userSpaceOnUse">
                    <stop stop-color="${en.color[0]}" offset="0" />
                    <stop stop-color="${en.color[2]}" offset="1" />
                </linearGradient>
                <path transform="translate(20)" d="m473.7 981.6s-7.1 9.5-11.3 11.4c-3.3 1.7-9.5 13.6-23.3 8.9-13.5-5.6-55.3-31.8-55.3-31.8l-58.1-29.9s-41.2-23.8-47-32.1-9.7-13.1-17.7-46.6c-8-33.3-27-122.5-27-122.5s-12.5-77.8 9.3-138.5c18.2-50.7 41-123.4 124.4-214.8 73.5-80.7 121-123.5 121-123.5v-5.3s21-21.9 41.3-20.7c14.8-2.6 48.9-4.4 51.8-7s31.5 0.9 33.4 8.6 10.2 50.8 11.1 63.9 3.7 84.6 3.7 84.6v72.2l-3.7 78.2-7.6 85.2s-6.9 65.1-8.2 66.3c-0.7 4.1-16.1 83.4-24.3 95.4-3.1 8.1-20.4 52.7-24.7 59.9-3.2 6.5-36.6 71.2-41 75.5-4.1 6.9-35.5 51.1-46.8 62.6z"
                    fill="url(#c${en.id})" opacity=".8" />
                    </g>
                    </g>
                <g class="en-three"><image transform="translate(345 523.14)" width="630" height="560" opacity=".9" overflow="visible" xlink:href="img/energy-bottom.png"
                />
                <g id="Color3">
                    <linearGradient id="b${en.id}" x1="-73.767" x2="-73.767" y1="974.01" y2="253.16" gradientTransform="matrix(-.92 .6 .53 .82 70.62 96.58)"
                        gradientUnits="userSpaceOnUse">
                        <stop stop-color="${en.color[1]}" offset="0" />
                        <stop stop-color="${en.color[0]}" offset="1" />
                    </linearGradient>
                    <path transform="translate(20)" d="m828.2 1079.5s11 3.3 15.5 2.5c3.7-0.5 15.1 5.2 24.8-6.2 9-12 32.3-55.8 32.3-55.8l35.7-55.9s24-41.6 24.9-51.3 1.8-15.7-8-46.2c-9.7-30.3-37.7-110-37.7-110s-28-67.3-77.3-102c-41.2-29-97.4-72.5-215.7-96.4-104.4-21.1-167.2-27.6-167.2-27.6l-2.6-4.1s-29.3-5.1-46.3 7.2c-14.2 6.3-44.8 24.1-48.6 23.8-3.8-0.4-27 18.4-24.7 25.5s16.5 45.1 22.2 55.7 39.1 67.6 39.1 67.6l36.1 55.8 42.3 58.5 49.3 61.7s38.6 46.5 40.3 46.7c2.7 2.8 55.7 55.6 68.9 60.2 6.8 4.5 44.1 29.3 51.4 32.5 6 3.2 67.4 34.5 73.4 35.4 6.9 3.2 56.3 19.9 71.9 22.4z"
                        fill="url(#b${en.id})" opacity=".8" />
                        </g>
                        </g>
                <g class="en-two"><image transform="translate(658 288.72)" width="354" height="717" opacity=".9" overflow="visible" xlink:href="img/energy-right.png"
                />
                <g id="Color2">
                <linearGradient id="a${en.id}" x1="218.58" x2="218.58" y1="767.17" y2="68.527" gradientTransform="rotate(160 412.85 433.02)"
                    gradientUnits="userSpaceOnUse">
                    <stop stop-color="${en.color[2]}" offset="0" />
                    <stop stop-color="${en.color[1]}" offset="1" />
                </linearGradient>
                <path transform="translate(20)" d="m682 317.9s3.2-10.4 6.2-13.3c2.3-2.5 4-14.6 17.4-14.9 13.4 0.7 57.4 10.5 57.4 10.5l59.3 7.9s42.8 7.8 50.3 13.2 12.4 8.5 29.6 34.9c17.1 26.2 60.8 97.3 60.8 97.3s34.7 63.2 34.5 122.2c-0.2 49.3 2.5 118.9-41.2 223.3-38.5 92-66.3 143.5-66.3 143.5l1.6 4.5s-11.4 25.3-29.2 30.5c-11.9 6.8-40.8 18.8-42.5 21.9s-27.4 8.9-31.4 2.8-24.4-40.7-29.2-51.6-29.1-71.7-29.1-71.7l-22.2-62.2-20.8-68.5-19.6-75.8s-14-58.2-13.3-59.7c-0.7-3.8-11.8-76.8-8.4-89.7 0.2-8 1.4-51.6 2.9-59.2 0.7-6.6 9.7-72.5 12.1-77.6 1.5-7.1 15-54.9 21.1-68.3z"
                    fill="url(#a${en.id})" opacity=".8" />
                    </g>
                    </g>
                <g class="meditate-circle meditate-one" fill="none" stroke="${en.color[2]}" stroke-width="10">
                    <circle class="st3 m-circle right" cx="1201.9" cy="913" r="38.5" />
                    <circle class="st3 m-circle left" cx="82.1" cy="913" r="38.5" />
                </g>
                <g class="meditate-circle meditate-two" fill="none" stroke="${en.color[0]}" stroke-width="10">
                    <circle class="st3 m-circle right" cx="1194.5" cy="718.1" r="38.5" />
                    <circle class="st3 m-circle left" cx="89.5" cy="718.1" r="38.5" />
                </g>
                <g class="meditate-circle meditate-three" fill="none" stroke="${en.color[2]}" stroke-width="10">
                    <circle class="st3 m-circle right" cx="1156" cy="523.1" r="38.5" />
                    <circle class="st3 m-circle left" cx="128" cy="523.1" r="38.5" />
                </g>
                <g class="meditate-circle meditate-four" fill="none" stroke="${en.color[1]}" stroke-width="10">
                    <circle class="st3 m-circle right" cx="1085" cy="328.2" r="38.5" />
                    <circle class="st3 m-circle left" cx="199" cy="328.2" r="38.5" />
                </g>
                <g class="meditate-circle meditate-five" fill="none" stroke="${en.color[0]}" stroke-width="10">
                    <circle class="st3 m-circle right" cx="899.7" cy="147.6" r="38.5" />
                    <circle class="st3 m-circle left" cx="384.4" cy="147.6" r="38.5" />
                </g>
                <g class="meditate-circle meditate-center">
                    <circle class="st3 m-circle" cx="642" cy="70.6" r="38.5" fill="none" stroke="${en.color[1]}" stroke-width="10" />
                </g>
            </svg>
        </div>`);


            let posx = (Math.random() * 1024).toFixed();
            let posy = (Math.random() * 768).toFixed();

            console.log(posx);

            $newMeditate.css({
                'position': 'absolute',
                'left': posx + 'px',
                'top': posy + 'px'
            }).appendTo('.energy');

            animateDiv($newMeditate);

        } else if (en.description == 'dancer') {

            $newDance = $(`<div class="d-svg">
            <?xml version="1.0" encoding="UTF-8"?><svg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="d${en.id}"><stop stop-color="${en.color[0]}" offset="0"/><stop stop-color="${en.color[1]}" offset=".5"/><stop stop-color="${en.color[2]}" offset="1"/></linearGradient></defs><g fill="none" stroke="url(#d${en.id})" stroke-linecap="round"><path class="d-lines d-six" d="m86.9 86.4c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.8-30.2-129.5-11.7-133.2 11.7-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.6 26.5-289.2 6.8c-21-19-6.6-41.5 32.9-55.1z" opacity=".6"/><path class="d-lines d-five" d="m86.9 77.4c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.8-30.2-129.5-11.7-133.2 11.7-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.6 26.5-289.2 6.8c-21-19-6.6-41.5 32.9-55.1z" opacity=".9"/><path class="d-lines d-four" d="m86.9 68.8c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.9-30.2-129.6-11.7-133.3 11.8-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.6 26.5-289.2 6.8c-20.9-19.1-6.5-41.6 33-55.2z" opacity=".6"/><path class="d-lines d-three" d="m86.9 59.4c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.8-30.2-129.5-11.7-133.2 11.7-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.6 26.5-289.2 6.8c-21-19-6.6-41.6 32.9-55.1z" opacity=".9"/><path class="d-lines d-two" d="m86.9 50.4c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.8-30.2-129.5-11.7-133.2 11.7-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.6 26.5-289.2 6.8c-21-19-6.6-41.6 32.9-55.1z" opacity=".6"/><path class="d-lines d-one" d="m86.9 40.6c39.5-13.6 130-6.1 139.7 8.9 9.9 15.4-32.7 29.6-47.5 44.4s-2.9 41.9 28.4 45c30.8 3.1 82-6.6 80.8-25.9-1.8-30.2-129.5-11.7-133.2 11.7-2.9 18.6 66.6 51.2 56.7 69.1s-122.5 37.1-153.5 0c-25.3-30.2-43.8-69.5 11.1-77.7 61.7-9.2 110.4 98.7 181.9 90 28.8-3.5 166.5-97.4 91.9-117.2s-267.7 26.7-289.3 6.9c-20.9-19.1-6.5-41.6 33-55.2z" opacity=".9"/></g></svg>
        </div>`);



            let posx = (Math.random() * 1024).toFixed();
            let posy = (Math.random() * 768).toFixed();

            console.log(posx);

            $newDance.css({
                'position': 'absolute',
                'left': posx + 'px',
                'top': posy + 'px'
            }).appendTo('.energy');

            animateDiv($newDance);

        } else if (en.description == 'explorer') {

            $newExplore = $(`<div class="e-svg">
            <?xml version="1.0" encoding="UTF-8"?><svg viewBox="0 0 149.32 189.08" xmlns="http://www.w3.org/2000/svg"><g data-name="Layer 2"><g data-name="Layer 8"><g class="explore-el e-five" stroke="${en.color[0]}"><path class="explore-path" d="M46.51,100.5a1.45,1.45,0,0,0-2.05.91A100.51,100.51,0,0,0,41.69,114c-.08.79-3.28.27-7.76.34a6.58,6.58,0,0,1-6.7-6.73c.15-6.08-.5-10.15-7.35-9.11-9.38,1.43-13.46,2.12-15.9-.16s-4.08,1.18-2,7.1,10.6,2.45,14.27,3.67-2.85,16.52,8.36,16.72,11.26,1.7,15,2.56c2.7.62,7.48-.72,7.4-5-.09-5.07-.06-16.74.33-21.46a1.45,1.45,0,0,0-.8-1.41Z"/><path class="explore-path" d="M102.05,101a1.49,1.49,0,0,1,2.08.91A99.1,99.1,0,0,1,107,114.47c.08.79,3.33.27,7.89.34a6.64,6.64,0,0,0,6.81-6.73c-.15-6.08.51-10.15,7.48-9.11,9.54,1.43,13.68,2.12,16.17-.16s4.15,1.18,2.07,7.1-10.78,2.45-14.51,3.67,2.9,16.52-8.5,16.72-11.45,1.7-15.28,2.56c-2.75.62-7.6-.72-7.52-5,.09-5.07.06-16.74-.33-21.46a1.44,1.44,0,0,1,.81-1.41Z"/></g><g class="explore-el e-six" stroke="${en.color[1]}"><path class="explore-path" d="M53.92,119.94a1.45,1.45,0,0,0-2.05.91,100.51,100.51,0,0,0-2.78,12.58c-.08.79-3.28.27-7.76.34a6.58,6.58,0,0,1-6.7-6.73c.15-6.08-.5-10.15-7.35-9.11-9.38,1.43-13.46,2.12-15.9-.16s-4.08,1.18-2,7.1,10.6,2.45,14.27,3.67S20.75,145.06,32,145.26s11.26,1.7,15,2.56c2.7.62,7.48-.72,7.4-5-.09-5.07-.06-16.74.33-21.46a1.45,1.45,0,0,0-.8-1.41Z"/><path class="explore-path" d="M94.52,120.43a1.49,1.49,0,0,1,2.08.91,99.1,99.1,0,0,1,2.82,12.58c.08.79,3.33.27,7.89.34a6.64,6.64,0,0,0,6.81-6.73c-.15-6.08.51-10.15,7.48-9.11,9.54,1.43,13.68,2.12,16.17-.16s4.15,1.18,2.07,7.1-10.78,2.45-14.51,3.67,2.9,16.52-8.5,16.72-11.45,1.7-15.28,2.56c-2.75.62-7.6-.72-7.52-5,.09-5.07.06-16.74-.33-21.46a1.44,1.44,0,0,1,.81-1.41Z"/></g><g class="explore-el e-seven" stroke="${en.color[1]}"><path class="explore-path" d="M62.78,139.34a1.45,1.45,0,0,0-2.05.91,100.51,100.51,0,0,0-2.78,12.58c-.08.79-3.28.27-7.76.34a6.58,6.58,0,0,1-6.7-6.73c.15-6.08-.5-10.15-7.35-9.11-9.38,1.43-13.46,2.12-15.9-.16s-4.08,1.18-2,7.1,10.6,2.45,14.27,3.67-2.85,16.52,8.36,16.72,11.26,1.7,15,2.56c2.7.62,7.48-.72,7.4-5-.09-5.07-.06-16.74.33-21.46a1.45,1.45,0,0,0-.8-1.41Z"/><path class="explore-path" d="M85.52,139.83a1.49,1.49,0,0,1,2.08.91,99.1,99.1,0,0,1,2.82,12.58c.08.79,3.33.27,7.89.34a6.64,6.64,0,0,0,6.81-6.73c-.15-6.08.51-10.15,7.48-9.11,9.54,1.43,13.68,2.12,16.17-.16s4.15,1.18,2.07,7.1-10.78,2.45-14.51,3.67,2.9,16.52-8.5,16.72-11.45,1.7-15.28,2.56c-2.75.62-7.6-.72-7.52-5,.09-5.07.06-16.74-.33-21.46a1.44,1.44,0,0,1,.81-1.41Z"/></g><g class="explore-el e-eight" stroke="${en.color[1]}"><path class="explore-path" d="M70.67,159.57a1.45,1.45,0,0,0-2.05.91,100.51,100.51,0,0,0-2.78,12.58c-.08.79-3.28.27-7.76.34a6.58,6.58,0,0,1-6.7-6.73c.15-6.08-.5-10.15-7.35-9.11-9.38,1.43-13.46,2.12-15.9-.16s-4.08,1.18-2,7.1,10.6,2.45,14.27,3.67-2.85,16.52,8.36,16.72,11.26,1.7,15,2.56c2.7.62,7.48-.72,7.4-5-.09-5.07-.06-16.74.33-21.46a1.45,1.45,0,0,0-.8-1.41Z"/><path class="explore-path" d="M77.49,160.06a1.49,1.49,0,0,1,2.08.91,99.1,99.1,0,0,1,2.82,12.58c.08.79,3.33.27,7.89.34a6.64,6.64,0,0,0,6.81-6.73c-.15-6.08.51-10.15,7.48-9.11,9.54,1.43,13.68,2.12,16.17-.16s4.15,1.18,2.07,7.1-10.78,2.45-14.51,3.67,2.9,16.52-8.5,16.72-11.45,1.7-15.28,2.56c-2.75.62-7.6-.72-7.52-5,.09-5.07.06-16.74-.33-21.46a1.44,1.44,0,0,1,.81-1.41Z"/></g><g class="explore-el e-four" stroke="${en.color[0]}"><path class="explore-path" d="M47.27,88.5a1.49,1.49,0,0,1-2.08-.91A99.1,99.1,0,0,1,42.36,75c-.08-.79-3.33-.27-7.89-.34a6.64,6.64,0,0,0-6.81,6.73c.15,6.08-.51,10.15-7.48,9.11C10.64,89.08,6.5,88.39,4,90.67s-4.15-1.18-2.07-7.1,10.78-2.45,14.51-3.67-2.9-16.52,8.5-16.72,11.45-1.7,15.28-2.56c2.75-.62,7.6.72,7.52,5-.09,5.07-.06,16.74.33,21.46a1.44,1.44,0,0,1-.81,1.41Z"/><path class="explore-path" d="M101.5,88.09a1.45,1.45,0,0,0,2.05-.91,100.51,100.51,0,0,0,2.78-12.58c.08-.79,3.28-.27,7.76-.34A6.58,6.58,0,0,1,120.8,81c-.15,6.08.5,10.15,7.35,9.11,9.38-1.43,13.46-2.12,15.9.16s4.08-1.18,2-7.1-10.6-2.45-14.27-3.67,2.85-16.52-8.36-16.72-11.26-1.7-15-2.56c-2.7-.62-7.48.72-7.4,5,.09,5.07.06,16.74-.33,21.46a1.45,1.45,0,0,0,.8,1.41Z"/></g><g class="explore-el e-three" stroke="${en.color[2]}"><path class="explore-path" d="M54.8,69.05a1.49,1.49,0,0,1-2.08-.91,99.1,99.1,0,0,1-2.82-12.58c-.08-.79-3.33-.27-7.89-.34A6.64,6.64,0,0,0,35.19,62c.15,6.08-.51,10.15-7.48,9.11-9.54-1.43-13.68-2.12-16.17.16S7.4,70,9.47,64.13,20.25,61.68,24,60.46s-2.9-16.52,8.5-16.72S43.93,42,47.76,41.18c2.75-.62,7.6.72,7.52,5-.09,5.07-.06,16.74.33,21.46a1.44,1.44,0,0,1-.81,1.41Z"/><path class="explore-path" d="M94.1,68.64a1.45,1.45,0,0,0,2.05-.91,100.51,100.51,0,0,0,2.78-12.58c.08-.79,3.28-.27,7.76-.34a6.58,6.58,0,0,1,6.7,6.73c-.15,6.08.5,10.15,7.35,9.11,9.38-1.43,13.46-2.12,15.9.16s4.08-1.18,2-7.1-10.6-2.45-14.27-3.67,2.85-16.52-8.36-16.72-11.26-1.7-15-2.56c-2.7-.62-7.48.72-7.4,5,.09,5.07.06,16.74-.33,21.46a1.45,1.45,0,0,0,.8,1.41Z"/></g><g class="explore-el e-two" stroke="${en.color[2]}"><path class="explore-path" d="M63.8,49.66a1.49,1.49,0,0,1-2.08-.91,99.1,99.1,0,0,1-2.82-12.58c-.08-.79-3.33-.27-7.89-.34a6.64,6.64,0,0,0-6.81,6.73c.15,6.08-.51,10.15-7.48,9.11-9.54-1.43-13.68-2.12-16.17.16s-4.15-1.18-2.07-7.1S29.25,42.28,33,41.06s-2.9-16.52,8.5-16.72,11.45-1.7,15.28-2.56c2.75-.62,7.6.72,7.52,5-.09,5.07-.06,16.74.33,21.46a1.44,1.44,0,0,1-.81,1.41Z"/><path class="explore-path" d="M85.24,49.25a1.45,1.45,0,0,0,2.05-.91,100.51,100.51,0,0,0,2.78-12.58c.08-.79,3.28-.27,7.76-.34a6.58,6.58,0,0,1,6.7,6.73c-.15,6.08.5,10.15,7.35,9.11,9.38-1.43,13.46-2.12,15.9.16s4.08-1.18,2-7.1-10.6-2.45-14.27-3.67,2.85-16.52-8.36-16.72-11.26-1.7-15-2.56c-2.7-.62-7.48.72-7.4,5,.09,5.07.06,16.74-.33,21.46a1.45,1.45,0,0,0,.8,1.41Z"/></g><g class="explore-el e-one" stroke="${en.color[2]}"><path class="explore-path" d="M71.83,29.42a1.49,1.49,0,0,1-2.08-.91,99.1,99.1,0,0,1-2.82-12.58c-.08-.79-3.33-.27-7.89-.34a6.64,6.64,0,0,0-6.81,6.73c.15,6.08-.51,10.15-7.48,9.11-9.54-1.43-13.68-2.12-16.17.16s-4.15-1.18-2.07-7.1S37.28,22.05,41,20.83s-2.9-16.52,8.5-16.72S61,2.41,64.79,1.55c2.75-.62,7.6.72,7.52,5-.09,5.07-.06,16.74.33,21.46a1.44,1.44,0,0,1-.81,1.41Z"/><path class="explore-path" d="M77.35,29a1.45,1.45,0,0,0,2.05-.91,100.51,100.51,0,0,0,2.78-12.58c.08-.79,3.28-.27,7.76-.34a6.58,6.58,0,0,1,6.7,6.73C96.49,28,97.14,32.06,104,31c9.38-1.43,13.46-2.12,15.9.16s4.08-1.18,2-7.1-10.6-2.45-14.27-3.67S110.52,3.9,99.3,3.7,88,2,84.27,1.14c-2.7-.62-7.48.72-7.4,5,.09,5.07.06,16.74-.33,21.46a1.45,1.45,0,0,0,.8,1.41Z"/></g></g></g></svg>

        </div>`);

            let posx = (Math.random() * 1024).toFixed();
            let posy = (Math.random() * 768).toFixed();

            console.log(posx);

            $newExplore.css({
                'position': 'absolute',
                'left': posx + 'px',
                'top': posy + 'px'
            }).appendTo('.energy');

            animateDiv($newExplore);

        } else {
            return false;
        }

        $('.card-contain').append(`<div class="card" id="${en.id}" data-name="${en.name}" data-loc="${en.location}" data-desc="${en.description}" data-spiceOne="${en.spices[0]}" data-spiceTwo="${en.spices[1]}" data-spiceThree="${en.spices[2]}" data-comment="${en.userComment}"><div class="energy-contain"></div><h2 class="name">${en.name}</h2><p class="location">${en.location}</p></div>`);

        console.log('card added');

        count++;



        var toTapDetail = $('.card');
        toTapDetail.hammer().on('tap', function () {
            $('.detail-name').html($(this).attr('data-name'));
            $('.detail-location').html($(this).attr('data-loc'));
            $('.detail-comment').html($(this).attr('data-comment'));
            $('.movement-select > .detail-desc').css('background-image', 'url(../img/selections/' + $(this).attr('data-desc') + '.svg)');
            $('.movement-select > span').html($(this).attr('data-desc'));
            $('.spice-select.one > .spice-bg').css('background-image', 'url(../img/fourth/spice/' + $(this).attr('data-spiceOne') + '.svg)');
            $('.spice-select.one > span').html($(this).attr('data-spiceOne'));
            $('.spice-select.two > .spice-bg').css('background-image', 'url(../img/fourth/spice/' + $(this).attr('data-spiceTwo') + '.svg)');
            $('.spice-select.two > span').html($(this).attr('data-spiceTwo'));
            $('.spice-select.three > .spice-bg').css('background-image', 'url(../img/fourth/spice/' + $(this).attr('data-spiceThree') + '.svg)');
            $('.spice-select.three > span').html($(this).attr('data-spiceThree'));
            $('.explore-detail').animate({
                right: '40px'
            }, 500);
        });

        var toTapDetailClose = $('.explore-detail .close');
        toTapDetailClose.hammer().on('tap', function () {
            $('.explore-detail').animate({
                right: '-840px'
            }, 500);
        });

    });

    var toTapBtnOne = $(".intro .next");
    toTapBtnOne.hammer().on("tap", function () {

        $("#inner").animate({
            left: '-1112',
            duration: "slow"
        });

    });

    var toTapBtnProject = $('.intro .project');
    toTapBtnProject.hammer().on('tap', function () {
        $('#inner').animate({
            left: '-7784',
            duration: 'slow'
        });
        $('.intro .project').css('display', 'none');
        // --- add lines and circles to projection
        for (i = 0; i < 16; i++) {
            let posx = (Math.random() * 1024).toFixed();
            let posy = (Math.random() * 768).toFixed();

            $newLine =
                $(`<div class="line"><svg xmlns="http://www.w3.org/2000/svg" width="83.83" height="79.74"><g id="e2b7835a-f7f5-41fb-8148-9b0e81aaf889" data-name="Layer 2"><g opacity=".3" fill="#fff" id="5f040068-b969-4712-a9a1-5e9491ccf1d5" data-name="Layer 1"><path class="17d33c1d-1b87-41a8-900a-897309caa8c4" d="M39.87 37.13C17.89 37.13 0 21.82 0 3a3 3 0 0 1 6 0c0 15.51 15.19 28.13 33.87 28.13a3 3 0 0 1 0 6z"/><path class="17d33c1d-1b87-41a8-900a-897309caa8c4" d="M80.83 79.74a3 3 0 0 1-3-3 39.66 39.66 0 0 0-39.62-39.61 3 3 0 0 1 0-6 45.67 45.67 0 0 1 45.62 45.61 3 3 0 0 1-3 3z"/></g></g></svg>
          </div>`);
            let randomRotate = (Math.random() * 360).toFixed();
            $newLine.css({
                'position': 'absolute',
                'left': posx + 'px',
                'top': posy + 'px',
                'transform': 'rotate(' + randomRotate + 'deg) scale(.5)'
            }).appendTo('#energy-projection').fadeIn(100);

            animateDiv($newLine);
        }
        for (i = 0; i < 12; i++) {
            let posx = (Math.random() * 1024).toFixed();
            let posy = (Math.random() * 768).toFixed();

            $newCircle =
                $(`<div class="circle"><svg xmlns="http://www.w3.org/2000/svg" width="13.78" height="13.78"><defs><style></style></defs><g id="2ccb77d6-cd3c-4660-a557-88711d7578f6" data-name="Layer 2"><path class="02565e62-631d-4d5e-8c29-f814184dc1c5" d="M6.89 13.78a6.89 6.89 0 1 1 6.89-6.89 6.9 6.9 0 0 1-6.89 6.89zm0-9.78a2.89 2.89 0 1 0 2.89 2.89A2.89 2.89 0 0 0 6.89 4z" id="4ef76696-f96f-4983-bfda-dd9f84cd73b2" data-name="Layer 1" fill="#fff" opacity=".3"/></g></svg></div>`);

            $newCircle.css({
                'position': 'absolute',
                'left': posx + 'px',
                'top': posy + 'px'
            }).appendTo('#energy-projection').fadeIn(100);

            animateDiv($newCircle);
        }
    });

    var toTapBtnExplore = $('.intro .explore');
    toTapBtnExplore.hammer().on('tap', function () {
        $('body').animate({
            left: '-8922'
        }, 500);
        $('#inner').animate({
            left: '-8884'
        }, 500);
        $('.intro .explore').css('display', 'none');
    });

    var toTapBtnTwo = $(".q1 .back");
    toTapBtnTwo.hammer().on("tap", function () {

        $("#inner").animate({
            left: '0',
            duration: "slow"
        });

    });

    var toTapBtnFour = $(".q2 .back");
    toTapBtnFour.hammer().on("tap", function () {

        $("#inner").animate({
            left: '-1112',
            duration: "slow"
        });

    });

    var toTapBtnFive = $(".q2 .next");
    toTapBtnFive.hammer().on("tap", function () {

        $("#inner").animate({
            left: '-3336',
            duration: "slow"
        });

    });

    var toTapBtnSix = $(".q3 .back");
    toTapBtnSix.hammer().on("tap", function (ee) {

        $("#inner").animate({
            left: '-2224',
            duration: "slow"
        });

    });
    var toTapBtnEight = $(".q4 .back");
    toTapBtnEight.hammer().on("tap", function (ee) {

        $("#inner").animate({
            left: '-3336',
            duration: "slow"
        });

    });

    var toTapBtnTen = $(".q5 .next");
    toTapBtnTen.hammer().on("tap", function () {
        userComment = $('#userStory').val();
        console.log(userComment);
        $("#inner").animate({
            left: '-6672',
            duration: "slow"
        });

        let id = Math.random().toString(36).substr(2, 9);

        energy = {
            id: id,
            name: name,
            location: location,
            color: colors,
            spices: spices,
            description: description,
            userComment: userComment
        }

        console.log(energy);
        socket.emit('myTap', energy);

        colors = [];
        energy = {};
        description = [];

    });
    var toTapBtnEleven = $(".q6 .next");
    toTapBtnEleven.hammer().on("tap", function () {

        $("#inner").animate({
            top: '-820',
            duration: "slow",

        }, function () {
            window.location.reload(true);
        });
		$('#username').reset();
		$('#userloc').reset();



    });

    var toTapBtnBegin = $('.explore-main .begin');
    toTapBtnBegin.hammer().on('tap', function () {
        $('body').animate({
            top: '-1112',
            duration: 'slow'
        });
    });

}

// Character Count Textarea
function countChar(val) {
    var len = val.value.length;
    if (len >= 500) {
        val.value = val.value.substring(0, 500);
    } else {
        $('#charNum').text(500 - len);
    }
};

// New position to move energy around energy projection
function makeNewPosition() {

    // Get viewport dimensions (remove the dimension of the div)
    var h = 1024 - 50;
    var w = 768 - 50;

    var nh = Math.floor(Math.random() * h);
    var nw = Math.floor(Math.random() * w);

    return [nh, nw];

}

// Animate div around energy projection
function animateDiv(e) {
    var newq = makeNewPosition();
    var oldq = [e.posx, e.poxy];
    var speed = 80;

    oldq[0] = $(e).offset().top;
    oldq[1] = $(e).offset().left;

    var a = newq[0] - oldq[0];
    var b = newq[1] - oldq[1];

    var distance = Math.sqrt(a * a + b * b);

    $(e).animate({
        top: newq[0],
        left: newq[1]
    }, distance * speed, 'linear', function () {
        animateDiv(e);
    });

};

// Console log frames per second each second for projection performance
// gameloopId = setInterval(gameLoop, 1000);

// var lastLoop = new Date;

// function gameLoop() {
//     var thisLoop = new Date;
//     var fps = 1000 / (thisLoop - lastLoop);
//     lastLoop = thisLoop;
//     console.log(fps);
// }
