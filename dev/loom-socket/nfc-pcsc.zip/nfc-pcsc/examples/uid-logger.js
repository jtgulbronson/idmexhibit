var express = require('express'),
	http = require('http');

//setting root
var app = express();
app.use(express.static(__dirname + "/"));

//setting the PORT, will be determined by Heroku or set to 5000 on local machine
var port = process.env.PORT || 5000;

var server = http.createServer(app);
server.listen(port);

console.log("http server listening on %d", port);

var io = require('socket.io')(server);

"use strict";


// #############
// Logs cards' uid
// #############

// import { NFC } from '../src/index';

const { NFC } = require('../src/index');

const nfc = new NFC();
var ar = [];
var connections = [];

nfc.on('reader', reader => {

	console.log(reader.name + ' reader attached, waiting for cards ...');

	reader.on('card', card => {
		console.log(card.uid + reader.name);
		// ar.push(card.uid + reader.name);
		ar.push(card.uid + reader.name);
		console.log(ar);

		if (ar.includes('044e39ca605780ACS ACR122U PICC Interface 0', '040537ca605781ACS ACR122U PICC Interface 1')) {
			io.sockets.on('connection', function (socket) {

				connections.push(socket);

				socket.broadcast.emit('paintingCheckedOne', ar);
				socket.emit('paintingCheckedOne', ar);
			});

		} else if (ar.includes('040537ca605781ACS ACR122U PICC Interface 0', '044e39ca605780ACS ACR122U PICC Interface 0')) {
			io.sockets.on('connection', function (socket) {

				connections.push(socket);

				socket.broadcast.emit('paintingCheckedTwo', ar);
				socket.emit('paintingCheckedTwo', ar);
			});
		} else {
			return false;
		}


		if (ar.length > 0) {
			//empty your array
			ar.length = 0;
		} else {
			return false;
		}
	});



	reader.on('error', err => {
		console.error('reader error', err);
	});

	reader.on('end', () => {
		console.log(reader.name + ' reader disconnected.');
	});


	nfc.on('error', err => {
		console.error(err);
	});

});
