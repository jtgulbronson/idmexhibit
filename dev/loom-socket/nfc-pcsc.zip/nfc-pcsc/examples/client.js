window.onload = function () {

	var socket = io.connect(location.origin.replace(/^http/, 'ws'));
	var wrapper = document.getElementById('wrapper');
	var paintingFrame;

    socket.on('connect', function () {

		console.log('this is a test');

	});

	socket.on('paintingCheckedOne', function(e) {
		console.log('painting one has been checked');
		
		wrapper.style.background = "blue";

	});

	socket.on('paintingCheckedTwo', function(e) {
		console.log('painting two has been checked');
		
		wrapper.style.background = "red";

	});
	
};